class box {
constructor (x,y,w,h){
this.width=w
this.height=h
var properties={
restitution :0.8,
friction:0.3,
density:1
}
this.body=object=Matter.Bodies.rectangle(x,y,w,h,properties)
Matter.World.add(world,this.body)
}
display(){
    rectMode(CENTER)
    var star=this.body.position
    push()
    translate(star.x,star.y)
    rotate(this.body.angle)
rect(0,0,this.width,this.height)
pop()
console.log(this.body.angle)
}
}