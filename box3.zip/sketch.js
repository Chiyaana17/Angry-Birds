var world;
var engine;
var object;
var ground1;
var box1;
var box2;
var box3;
function setup() {
  createCanvas(800,400);
  engine=Matter.Engine.create()
  world=engine.world
  ground1=new ground (width/2,height-10,width,20)
  box1=new box (200,100,30,70)
  box2=new box (210,170,30,70)
  box3=new box (200,240,30,70)
}
function draw() {
  background("#FFD700");
  Matter.Engine.update(engine)
  ground1.display()
  box1.display()
  box2.display()
  box3.display()
}